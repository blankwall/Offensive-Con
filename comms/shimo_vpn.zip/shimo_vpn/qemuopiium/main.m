//
//  main.m
//  qemuopiium
//
//  Created by tybohan on 8/28/18.
//  Copyright © 2018 tybohan. All rights reserved.
//

#import <Foundation/Foundation.h>

static NSString* kBGMXPCHelperMachServiceName = @"com.feingeist.shimo.helper";

// The protocol that BGMApp will vend as its XPC API.
@protocol BGMAppXPCProtocol
- (void) runVpncScript:(NSString*) o withReason:(NSString*)pep withReply:(void (^)(NSError*))reply;
@end

int main(int argc, const char * argv[]) {
    @autoreleasepool {
        
        NSString*  _serviceName = kBGMXPCHelperMachServiceName;

        NSXPCConnection* _agentConnection = [[NSXPCConnection alloc] initWithMachServiceName:_serviceName options:4096];
        [_agentConnection setRemoteObjectInterface:[NSXPCInterface interfaceWithProtocol:@protocol(BGMAppXPCProtocol)]];
        [_agentConnection resume];

        //        run user script as root/
        [[_agentConnection remoteObjectProxyWithErrorHandler:^(NSError* error) {
            (void)error;
            NSLog(@"Failure");
        }] runVpncScript:@"/tmp/root.py" withReason:@"give me root" withReply:^(NSError* reply) {
            NSLog(@"Failure!");
        }];
        NSLog(@"Success!");

    }
    return 0;
}
